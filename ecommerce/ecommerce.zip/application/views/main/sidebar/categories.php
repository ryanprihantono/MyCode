<div class="sidebar-box">
    <h1 class="sidebar-head">Categories</h1>
    <div class="sidebar-submenu" id="categories" style="font-size:14px">
        <?php echo $categories; ?>
    </div>
</div>