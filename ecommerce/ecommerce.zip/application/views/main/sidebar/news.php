<div class="sidebar-box">
    <h1 class="sidebar-head">News</h1>
    
    <div class="sidebar-cycle">
        <!-- looping -->
       	<?php
			foreach($news->result() as $row){
        ?>
        <div class="sidebar-content">  
            <div class="img-box">
                <a href="<?php echo base_url()."main/news/".$row->news_id;?>"><img width="194" src="<?php echo base_url(); ?>assets/uploads/news_images/<?php echo $row->picture; ?>"/></a>
            </div>
            <p class="posttime">
                <?php echo $row->date; ?>
            </p>
            
            <h1 class="sidebar-subhead"><?php echo $row->title; ?></h1>
            <p class="desc"><?php echo $row->news; ?></p>
            <p class="readmore">
                <a href="<?php echo base_url()."main/news/".$row->news_id;?>">Read More</a>
            </p>
        </div>
        <?php
			}
        ?>
        
    </div>
</div>