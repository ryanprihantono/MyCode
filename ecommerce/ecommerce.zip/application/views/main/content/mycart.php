<div id="tr_box">
    <h1 class="head-mainbar">My Cart</h1>
    <?php echo $table; ?>
</div>
<div class="clear"></div>
