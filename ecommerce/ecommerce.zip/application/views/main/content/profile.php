
<h1 class="head-mainbar">My Profile</h1>
    <div id="tabs">
        <ul>
            <li><a href="#tabs-1">Edit Profile</a></li>
            <li><a href="#tabs-2">Transactions</a></li>
            
        </ul>
        <div id="tabs-1">
            <?php include "profile/edit_profile.php"; ?>
        </div>
        <div id="tabs-2">
        	<?php include "profile/transactions.php"; ?>
            
        </div>
    </div>
<div class="clear"></div>