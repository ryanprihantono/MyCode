<div id="tr_box">
	<?php
	if($mainbar=='profile/transactions'){
	?>
	<h1 class="head-mainbar" style="margin-bottom:50px">Transactions</h1>
    
	<?php }echo $transactions; ?>
</div>