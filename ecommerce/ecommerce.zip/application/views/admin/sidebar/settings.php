<div class="sidebar">
	<h1>Settings</h1>
    <ul>
    	<li><a href="<?php echo base_url().'admin/welcome'; ?>" class="listMenu">Welcome Page</a></li>
        <li><a href="<?php echo base_url().'admin/new_arrival'; ?>" class="listMenu">New Arrival Page</a></li>
        <li><a href="<?php echo base_url().'admin/featured'; ?>" class="listMenu">Featured Product Page</a></li>
    	<li><a href="<?php echo base_url().'admin/message'; ?>" class="listMenu">Contact Us Messages</a></li>
    	<li><a href="<?php echo base_url().'admin/news'; ?>" class="listMenu">News</a></li>
        <li><a href="<?php echo base_url().'admin/how_to_order'; ?>" class="listMenu">How To Order Page</a></li>
        <li><a href="<?php echo base_url().'admin/term_of_service'; ?>" class="listMenu">Term Of Service Page</a></li>
        <li><a href="<?php echo base_url().'admin/contactus'; ?>" class="listMenu">Contact Us Page</a></li>
    </ul>
</div>