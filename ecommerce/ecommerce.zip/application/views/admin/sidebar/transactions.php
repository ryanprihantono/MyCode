<div class="sidebar">
	<h1>Transactions</h1>
    <ul>
        <li><a href="<?php echo site_url('admin/transactions'); ?>" class="listMenu">Payment Verification</a></li>
        <li><a href="<?php echo site_url('admin/shipment'); ?>" class="listMenu">Verified Payment and Shipment</a></li>
        <li><a href="<?php echo site_url('admin/history'); ?>" class="listMenu">Transactions History</a></li>
    </ul>
</div>