<div class="sidebar">
	<h1>Products and Master Table</h1>
    <ul>
        <li><a href="<?php echo base_url().'admin/category'; ?>" class="listMenu">Category Product</a></li>
        <li><a href="<?php echo base_url().'admin/subcategory'; ?>" class="listMenu">Subcategory Product</a></li>
        <li><a href="<?php echo base_url().'admin/color'; ?>" class="listMenu">Product Color</a></li>
        <li><a href="<?php echo base_url().'admin/product'; ?>" class="listMenu">Product</a></li>
        <li><a href="<?php echo base_url().'admin/bank'; ?>" class="listMenu">Bank</a></li>
    </ul>
</div>