<?php
	include 'datatables_js.php'; 
	echo $table; 
?>