<div id="list">
    <ul>
        <li><a href="<?php echo base_url().'main/departement'; ?>" class="listMenu">Departement</a></li>
        <li><a href="<?php echo base_url().'main/section'; ?>" class="listMenu">Section</a></li>
        <li><a href="<?php echo base_url().'main/title'; ?>" class="listMenu">Title</a></li>
        <li><a href="<?php echo base_url().'main/employeetype'; ?>" class="listMenu">Employee Type</a></li>
        <li><a href="<?php echo base_url().'main/employee'; ?>" class="listMenu">Employee</a></li>
        <li><a href="<?php echo base_url().'main/report'; ?>" class="listMenu">Report Attendence</a></li>
    </ul>
</div>