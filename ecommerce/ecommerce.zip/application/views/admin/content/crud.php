<?php
  if(isset($output))
	  echo $output;
  else{
  }
?>